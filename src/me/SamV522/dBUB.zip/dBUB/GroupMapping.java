package me.SamV522.dBUB;

import org.bukkit.entity.Player;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;

/**
 * Created by IntelliJ IDEA.
 * Author: SamV522
 * Date: 9/02/12
 * To change this template use File | Settings | File Templates.
 */
public class GroupMapping {

    public static String getGroupFromDb(Player base)
    {
        String retString = null;
        String dbGroupID = null;
        //Database db = Main.db;

        
        if(Main.db.isConnected()){
            String queryString = "SELECT "+Main.Config.getString("database.users.group-column")+
                                 " FROM "+ Main.Config.getString("database.users.table")+" WHERE "+
                                 Main.Config.getString("database.users.username-column")+" = "+
                                 base.getDisplayName().replace('"', '\"');
            ResultSet rs = Main.db.sendQuery(queryString);
            try{
                while(rs.next())
                {
                    dbGroupID = rs.getString(Main.Config.getString("database.users.group-column"));
                }
            }catch(SQLException e){
                Main.pluginLogger.log(Level.WARNING, "Database error:");
                Main.pluginLogger.log(Level.WARNING, e.getMessage());
            }
        }else{
            Main.pluginLogger.log(Level.WARNING, "User \""+base.getDisplayName()+
                    "\" connected while Database is not connected!");
        }
            retString = Main.Config.getString("group-mapping."+ dbGroupID);
        return retString;
    }
    
    public static void setdBGroup(Player base, String dbGroupID, String newGroupID)
    {
        String queryString="UPDATE "+ Main.Config.getString("database.users.table")+
        "SET "+ Main.Config.getString("database.users.group-column")+"="+newGroupID+
        "WHERE "+ Main.Config.getString("database.users.username-column")+"="+base.getDisplayName();
    }
}
